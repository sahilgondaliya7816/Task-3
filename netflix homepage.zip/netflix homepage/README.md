# Netflix Clone - HTML & CSS only

![Design preview for Netflix Clone](./design/desktop-design.jpg)

## Welcome! 👋

Clone web application of Netflix.com using HTML and CSS only. This will help you understand the basics of HTML & CSS where you will get to know about various new things in CSS including CSS variables, CSS Flex, CSS Grid and CSS media queries.
## Tech Stack

**Client:** HTML, CSS

## Deployment

Deploy this project on Github Pages / Vercel / Netlify.

**Live URL:** https://silly-lamington-e7034f.netlify.app/